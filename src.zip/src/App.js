import React from 'react';
import HomeScreen from './components/HomeScreen.jsx';
import './App.css';

function App() {
  return (
    <div className="App">
      <HomeScreen />
    </div>
  );
}

export default App;